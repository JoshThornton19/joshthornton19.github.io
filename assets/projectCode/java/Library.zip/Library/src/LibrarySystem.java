public class LibrarySystem {
	public static void main(String[] args) {
		// create books
		Book b1 = new Book("B001", "Divergent", "Veronica Roth");
		Book b2 = new Book("B002", "Green Eggs and Ham", "Dr Seuss");

		// get details of books

		// b1
		System.out.println("New book created: " + b1.getBookID() + ", " + b1.getTitle());

		// b2
		System.out.println("New book created: " + b2.getBookID() + ", " + b2.getTitle());

		
		// adding messages to show state of book
		if (b1.borrow("m1234")) {
			System.out.println(b1.getBookID() + " has been borrowed");
		} else {
			System.out.println(b1.getBookID() + " is not availiable");
		}


		if (b1.returnBook()) {
			System.out.println("Book returned");
		} else {
			System.out.println("Book not on loan");
		}
		
		

		
		// print book info
		System.out.println(b1.toString());
		System.out.println(b2.toString());

	}
}