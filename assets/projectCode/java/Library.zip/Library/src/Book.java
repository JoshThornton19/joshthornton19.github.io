public class Book
{
	// instance variable declarations
	// we do not have all information required to initialise the variables.
	// good to do all initialising in the constructor
	private String bookID;
	private String title;
	private String author;
	private String borrowerID;



	
	// constructor - must initialise all variables.
	public Book(String bookID, String title, String author) {
		this.bookID = bookID;
		this.title = title;
		this.author = author;
		this.borrowerID = null; // we dont know borrowerID so we initialise as null.
	}

	public String getBookID() {
		return this.bookID;
	}

	public String getTitle() {
		return this.title;
	}

	public boolean borrow(String borrowerID) {
		boolean result;
		if(borrowerID == null) {
			this.borrowerID = borrowerID;
			result = true;

		} else {
			result = false;
		}
		return result;
	}
	
	// method which allows the Book to be "returned" if it has been borrowed
	public boolean returnBook()
	{
		boolean result;
		// if borrower ID has been set (ie. book has been borrowed)
		if (this.borrowerID != null)
		{
			// reset borrowerID to null and return true result
			this.borrowerID = null;
			result = true;
		} else
		{
			// otherwise book is not currently borrowed so return false result
			result = false;
		}
		return result;
	}
	
	
	// format Book details to a String (useful for printing!)
	public String toString()
	{
		return String.format(
				"Book ID: %s\nTitle: %s\nAuthor: %s\nBorrowed by: %s\n",
				this.bookID, this.title, this.author,
				this.borrowerID != null ? this.borrowerID : "Available");
	}
} 




