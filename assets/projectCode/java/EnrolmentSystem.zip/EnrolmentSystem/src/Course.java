
public class Course {
	private String name;
	private String id;
	private String[] studentIDs;
	private int numEnrollments;
	
	
	
	public Course(String name, String id) {
		this.name = name;
		this.id = id;
		this.studentIDs = new String[30];
		this.numEnrollments=0;
		
		System.out.printf("***New course: %s created. ID = %s*** \n", name, id);
	}
	
	public void addStudent(String target) {
		if(numEnrollments<30) {
		this.studentIDs[this.numEnrollments] = target;
		this.numEnrollments+=1;
		}
	}
	
	
	public String toString() {
		String concat = "Enrolled IDs: ";
		for(int i=0;i<this.numEnrollments;i++) {
			concat = concat + this.studentIDs[i] + "\n";
		}
		
		return String.format("Course ID: %s\nName: %s\n %s", this.id, this.name, concat);
		
		
	}
	
}
