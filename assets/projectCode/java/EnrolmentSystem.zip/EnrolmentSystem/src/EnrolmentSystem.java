
public class EnrolmentSystem {

	public static void main(String[] args) {
		
		// create courses
		
		Course c1 = new Course("Programming", "COSC0000");
		Course c2 = new Course("Design", "COSC1234");
		
		// create students
		Student s1 = new Student("s1234", "Bill", "Nye");
		Student s2 = new Student("s8765", "Rob", "Dog");

		
			
		
		
		c1.addStudent(s1.getID());
		c1.addStudent(s2.getID());
		
		// print student info
		System.out.println(s1.toString());
		System.out.println(s2.toString());

		// print course info
		System.out.println(c1.toString());
		System.out.println(c2.toString());
	}

}
