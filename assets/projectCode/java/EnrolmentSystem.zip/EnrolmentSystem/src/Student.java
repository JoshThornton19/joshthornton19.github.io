
public class Student {
	private String id;
	private String fName;
	private String lName;

	

	// ctor
	public Student(String id, String fName, String lName) {
		this.id = id;
		this.fName = fName;
		this.lName = lName;
	

		System.out.printf("===New student: %s %s created. ID = %s=== \n", fName, lName, id);

	}

	
	public String getID() {
		return this.id;
	}
	


	public String toString() {
		return String.format("Student ID: %s\nFirst Name: %s\nLast Name: %s\n", this.id, this.fName, this.lName);
		
		
	}

}
